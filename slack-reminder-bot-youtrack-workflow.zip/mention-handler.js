const entities = require('@jetbrains/youtrack-scripting-api/entities');
const http = require('@jetbrains/youtrack-scripting-api/http');
const SLACK_BOT__URL = '<your slack bot server host>/youtrack/mention';

exports.rule = entities.Issue.onChange({
  title: 'Mention-handler',
  guard: (ctx) => {
    return ctx.issue.comments.added.isNotEmpty();
  },
  action: (ctx) => {
    const issue = ctx.issue;
    const connection = new http.Connection(SLACK_BOT__URL, null, 2000);
    connection.addHeader("Content-Type", "text/html; charset=utf-8");
    issue.comments.added.forEach(function(com) {
      com.text.split(' ').filter(function(str) {
        return str.startsWith('@');
      }).map(cur => cur.substr(1, cur.length)).forEach(function(tagname) {
        const user = entities.User.findByLogin(tagname);
        if (user != null) {
          var userEmail = com.author.email;
          if (userEmail != null) {
            userEmail = userEmail.toLowerCase();
          }

          console.log(com.author.login);
          const payload = {
            'issueId': issue.id,
            'projectName': issue.project.name,
            'userEmail': user.email.toLowerCase(),
            'link': com.url
          };
          if (user.email.toLowerCase() !== com.author.email.toLowerCase()) {
            const response = connection.postSync('', null, JSON.stringify(payload));
            if (!response.isSuccess) {
              console.log('Failed to post notification to Slack. Details: ' + response.toString());
            }
          }
        }
      });

    });
  },
  requirements: {}
});