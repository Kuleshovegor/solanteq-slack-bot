const entities = require('@jetbrains/youtrack-scripting-api/entities');
const http = require('@jetbrains/youtrack-scripting-api/http');

const SLACK_BOT__URL = '<your slack bot server host>/youtrack/newtask';

exports.rule = entities.Issue.onChange({
  title: 'New-task-handler',
  guard: (ctx) => {
    return ctx.issue.becomesReported;
  },
  action: (ctx) => {
    const issue = ctx.issue;
    
    var assigneeEmail;
    if (issue.fields.Assignee == null) {
      assigneeEmail = null;
    } else {
      assigneeEmail = issue.fields.Assignee.email;
    }
    const payload2 = {
      'id' : issue.id,
      'ownerEmail' : issue.project.leader.email,
      'priority' : issue.fields.Priority.name,
      'projectName': issue.project.name,
      'summary' : issue.summary,
      'assigneeEmail' : assigneeEmail,
      'description' : issue.description
    };

    const connection = new http.Connection(SLACK_BOT__URL, null, 2000);
    connection.addHeader("Content-Type", "text/html; charset=utf-8");
    const response = connection.postSync('', null, JSON.stringify(payload2));
    if (!response.isSuccess) {
      console.warn('Failed to post notification to Slack. Details: ' + response.toString());
    }
  },
  requirements: {
  }
});